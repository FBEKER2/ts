const Discord = require('discord.js')
const os = require('os')
var speedTest = require('speedtest-net');

exports.run = (client, message) => {
      message.channel.send(`<a:yukleniyor:653204706050572298> Bu Biraz Zaman Alabilir, Lütfen Bekleyin...`).then(m => m.delete(20000));
  var osType = os.type();

  if (osType === 'Darwin') osType = 'macOS'
  else if (osType === 'Windows') osType = 'Windows'
  else if (osType === 'Linux') osType = 'Linux'
  else if (osType === 'Ubuntu') osType = 'Ubuntu'
  else osType = os.type();
    var test = speedTest({maxTime: 5000});
    test.on('data', data => {
const embed = new Discord.RichEmbed()
 .setColor(0x36393F)
.setTitle('**TRUX Anlık Hız Testi Sonuçları**')
.addField('**Anlık İstatistikler**', `İndirme: **${data.speeds.download}**
Yükleme: **${data.speeds.upload}**`)
.addField('**Nolmal Olarak Ölçülen İstatistikler**', `İndirme: **${data.speeds.originalDownload}**
Yükleme: **${data.speeds.originalUpload}**`)
.addField('**Pingler**', `Discord API Pingi: **${client.ping}**
Speedtestde Ölçülen Ping: **${data.server.ping}**`)
.addField('**Diğer Bilgiler**', `İnternet Portunun IP'sı: **IP'mi Vermem Kanka**
İşletim Sistemi: **${osType}**
İnternet Sağlayıcısı: **Bekerhosting.com**
Host: **www.bekerhosting.com**
Lokasyon: **Türkiye**
Sağlayıcı Lokasyonu: **Türkiye İstanbul**
Sağlayıcı Sponsoru: **İfasTnet**`)
  message.channel.send(embed)
});

    test.on('error', err => {
  console.log(err);
});
}


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: 'speedtest',
  description: 'speedtest yapar',
  usage: 'speedtest'
};