const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597495611524251660> `/ping`', '➠ **Pinginizi Gösterir.**.')
   .addField('<a:gold:597495611524251660> `/servericon`', '➠ **Sunucunun Resmini Gönderir.**.')
   .addField('<a:gold:597495611524251660> `/sunucubilgi`', '➠ **Sunucunun Bilgilerini Gösterir.**.')
   .addField('<a:gold:597495611524251660> `/to10`', '➠ **Botun Bulunduğu En Çok Kişiye Sahip Olan 10 Sunucuyu Gösterir..**.')


   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "ekstra",
  description: "Gerekli komutları gösterir.",
  usage: "ekstra"
};