const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597497124535664661> `/çal`', '➠ **Şarkı Çalar.**.')
   .addField('<a:gold:597497124535664661> `/geç`', '➠ **Şarkıyı Geçer.**.')
   .addField('<a:gold:597497124535664661> `/durdur`', '➠ **Şarkıyı Durdurur..**.')
   .addField('<a:gold:597497124535664661> `/sıra`', '➠ **Sıradaki Şarkıları Gösterir.**.')
   .addField('<a:gold:597497124535664661> `/çalan`', '➠ **Çalan Şarkıyı Gösterir.**.')
   .addField('<a:gold:597497124535664661> `/ses`', '➠ **Şarkının Sesini Ayarlar.**.')


   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "müzik",
  description: "Gerekli komutları gösterir.",
  usage: "müzik"
};