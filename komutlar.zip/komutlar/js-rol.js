const Discord = require("discord.js");
const client = new Discord.Client();
const DBL = require("dblapi.js");
const dbl = new DBL('DBL TOKEN', client);
exports.run = (client, message) => {
    dbl.hasVoted(message.author.id).then(voted => {
        if (!voted) {
            message.reply("Bu komutu kullanabilmek için DBL üzerinden oy vermen gerekiyor. (Eğer oy verdiyseniz bi kaç dakika bekleyin .s) \nOy vermek için: ") //OY LINKI!

        } else {
            message.channel.send("JavaScript rolün verildi.");
            message.member.addRole("ROL ID!")  //ROL ID!

        }
    })
}
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["JavaScript"],
  permLevel: 0,
   
};

exports.help = {
  name: 'js',
  description: 'Oy vererek js rol al!',
  usage: 'js'
};