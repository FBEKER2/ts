const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597496371179683874> `/saat`', '➠ **Saati Gösterir**.') 
   .addField('<a:gold:597496371179683874> `/soru-sor`', '➠ **Bota Soru Sorarsınız**.') 
   .addField('<a:gold:597496371179683874> `/hocayasor`', '➠ **Hocaya Soru Sorarsınız**.') 
   .addField('<a:gold:597496371179683874> `/mcödül`', '➠ **Kanala Minecraft Efektli Bir Ödül Resmi Gönderir**.')
   .addField('<a:gold:597496371179683874> `/kısalt`', '➠ **İstediğiniz Bir Linki Kısaltır**.')
   .addField('<a:gold:597496371179683874> `/döviz`', '➠ **Döviz Bilgilerini Gösterir**.')
   .addField('<a:gold:597496371179683874> `/hesapla`', '➠ **Matematik Sorusu Hesaplar**.')
   .addField('<a:gold:597496371179683874> `/komutlar`', '➠ **Botta Bulunan Toplam Komut Sayısını Gösterir**.')
   
   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "kullanıcı2",
  description: "Gerekli komutları gösterir.",
  usage: "kullanıcı2"
};