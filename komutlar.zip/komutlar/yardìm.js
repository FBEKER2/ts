const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   
   
   .addField('<a:yardm:597877423824175115> `/yetkili`', '➠ **Bot Hakkında Komutları Gösterir**.')
   .addField('<a:eglence:597166762278125608> `/eğlence`', '➠ **Eğlence Komutlarını Gösterir**.')
   .addField('<a:eglence:597166813737910294> `/eğlence2`', '➠ **2. Eğlence Komutlarını Gösterir**.')
   .addField('<a:oyun:597167502208008237> `/ekstra`', '➠ **Ekstra Komutları Gösterir**.')
   .addField('<a:muzik:597169232635101189> `/müzik`', '➠ **Müzik Komutlarını Gösterir**.')
   .addField('<a:kullanci:597169775604400139> `/kullanıcı`', '➠ **Herkesin Kullana Bileceği Komutları Gösterir**.')
   .addField('<a:kullanci:597169822526210089> `/kullanıcı2`', '➠ **2. Herkesin Kullana Bileceği Komutları Gösterir**.')
   
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "yardım",
  description: "Gerekli komutları gösterir.",
  usage: "yardım"
};