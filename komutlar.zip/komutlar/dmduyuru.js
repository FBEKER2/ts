const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = (client, message, args) => {
if (message.author.id !=543019606999302174) { return; }
let mesaj = args.slice(0).join(' ');
if (mesaj.length < 1) return message.channel.send('Birşey Yazmalısınız');
message.delete();
const mesajat = new Discord.RichEmbed()
.setColor('RANDOM')
.setDescription('' + mesaj + '')

client.users.forEach(u => {
  u.sendEmbed(mesajat)
})
};

exports.conf = {
enabled: true,
guildOnly: false,
aliases: ['duyur','duyuru'],
permLevel: 0
};

exports.help = {
name: 'dmduyuru',
description: 'Merhaba Beni Sunucuna Eklemek İster mİsin? Yeni Çıktım 100 Den Fazla Komutum Var Ve Ayrıca Havalı Yardım Münülerim Var Eğer Eklemek İstersen https://discordapp.com/oauth2/authorize?client_id=580476521760817162&scope=bot&permissions=8 Bekliyorum  .',
usage: 'duyuru [duyurmak istediğiniz şey]'
};