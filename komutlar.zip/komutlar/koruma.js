const Discord = require('discord.js');
const db = require('quick.db');

exports.run = async(client, message, args) => {

  if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(` Bu komudu kullanabilmek için "Sunucuyu Yönet" yetkisine sahip olman gerek.`)
  if (!args[0]) return message.channel.send(`:no_entry: Koruma sistemini Ayarlamak İçin \`/koruma aç\` | Kapatmak İstiyorsanız \`/koruma kapat\` Yazabilirsiniz`)
  if (args[0] !== 'aç' && args[0] !== 'kapat') return message.channel.send(`:no_entry: Koruma sistemini Ayarlamak İçin \`/koruma aç\` | Kapatmak İstiyorsanız \`/koruma kapat\` Yazabilirsiniz`)

    if (args[0] == 'aç') {
    db.set(`sunucular.${message.guild.id}.koruma`, 'aktif')
    let i = await db.fetch(`sunucular.${message.guild.id}.koruma`)
  message.channel.send(`Self-Bot Koruması başarıyla **aktif** olarak ayarlandı.`)   
    
  }

  if (args[0] == 'kapat') {
      
    db.delete(`sunucular.${message.guild.id}.koruma`)
    
    message.channel.send(`Koruma sistemini Kapattım.`)
  }
 
};


exports.conf = {
  enabled: true,
  aliases: [],
  guildOnly: false,
  permLevel: 0
};

exports.help = {
  name: 'koruma',
  description: 'Spambotların saldırılarını engeller',
  usage: 'koruma <aç/kapat>'
};