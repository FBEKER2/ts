const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597165297484693545> `/balıktut`', '➠ **Balık Tutar.*.')
   .addField('<a:gold:597165297484693545> `/troll`', '➠ **Troll Resmi Koyar.*.')

   
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "eğlence2",
  description: "Gerekli komutları gösterir.",
  usage: "eğlence2"
  
};