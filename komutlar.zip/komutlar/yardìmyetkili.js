const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597163529077784579> `/ban`', '➠ **Belirtiğiniz Kullanıcıyı Sunucudan Tamamen Uzaklaştırır.**.')
   .addField('<a:gold:597163529077784579> `/unban`', '➠ **Belirttiğiniz Kullanıcının Yasağını Kaldırırsınız.**.')
   .addField('<a:gold:597163529077784579> `/banliste`', '➠ **Banlanan Kişileri Gösterir.**.')
   .addField('<a:gold:597163529077784579> `/kick`', '➠ **Belirttiğiniz Kullanıcıyı Sunucudan Atar.**.')
   .addField('<a:gold:597163529077784579> `/sustur`', '➠ **Belirttiğiniz Kullanıcıyı Susturur.**.')
   .addField('<a:gold:597163529077784579> `/yavaşmod`', '➠ **Bir Kanala Slowmode Koyarsınız.**.')
   .addField('<a:gold:597163529077784579> `/giveaway`', '➠ **Süreli Çekiliş Yapabilirsiniz.**.')
   .addField('<a:gold:597163529077784579> `/temizle`', '➠ **Mesajları Temizler.**.')
   .addField('<a:gold:597163529077784579> `/yaz`', '➠ **Bota Yazdığınız Mesajı Yazdırırsınız.**.')
   .addField('<a:gold:597163529077784579> `/reklam-engelleme`', '➠ **Reklam Engellemeyi Açarsınız.**.')
   .addField('<a:gold:597163529077784579> `/küfürengelle`', '➠ **Küfür Engellemeyi Açarsınız.**.')
   .addField('<a:gold:597163529077784579> `/sunucu-kur`', '➠ **Yeni Açılmış Bir Sunucuyu Odalarla Birlikte Hızlıca Kurar.**.')
   .addField('<a:gold:597163529077784579> `/sayaç`', '➠ **Sunucuya Girenlen Kullanıcıları Sayar.**.')
   .addField('<a:gold:597163529077784579> `/otorol`', '➠ **Sunucuya Giren Kullanıcılara Otomatik Rol Verir.**.')
   .addField('<a:gold:597163529077784579> `/prefix`', '➠ **Botun Ön Ekini Değiştirir.**.')
   .addField('<a:gold:597163529077784579> `/özelkomutekle`', '➠ **Özel Komut Ekleminizi Sağlar.**.')
   .addField('<a:gold:597163529077784579> `/unload`', '➠ **İstediğiniz Bir Komutu Devre Dışı Bırakır.**.')
   .addField('<a:gold:597163529077784579> `/kayit`', '➠ **Sunucuya Üye Kayit Eder.**.')
   .addField('<a:gold:597163529077784579> `/eval`', '➠ **Yazılan Kodu Çalıştırır.**.')
   .addField('<a:gold:597163529077784579> `/kilit`', '➠ **Kanalı İstediğiniz Süreye K Kilitler.**.')
   .addField('<a:gold:597163529077784579> `/rol-ver`', '➠ **Belirttiğiniz Kullanıcıya Rol Verir.**.')
   .addField('<a:gold:597163529077784579> `/reklam-taraması`', '➠ **Reklam Yapan Kullanıcıları Bulur.**.')
   .addField('<a:gold:597163529077784579> `/rol-koruma aç`', '➠ **Sunucudaki Rolleri Koruma Altına Alır.**.')
   .addField('<a:gold:597163529077784579> `/seviye-ayarla aç`', '➠ **Seviye Sistemini Ayarlarsınız.**.')
   
   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "yetkili",
  description: "Gerekli komutları gösterir.",
  usage: "yetkili"
};
