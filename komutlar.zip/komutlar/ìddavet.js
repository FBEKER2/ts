const Discord = require("discord.js");
module.exports.run = async (client, message, args) => {
    if (message.author.id !== "599680344719097882") return;
    let sv = client.guilds.get(args[0])
    if (!sv) return message.channel.send(`Sunucu ID'si girmelisin.`)
    sv.channels.random().createInvite().then(a => message.author.send(a.toString()))

}
module.exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: 0
};

module.exports.help = {
  name: 'ıd-al',
  description: 'It is secret bro .p',
  usage: 'invite'
};