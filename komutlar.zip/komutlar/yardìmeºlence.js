const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597165297484693545> `/8ball`', '➠ **Bota Soru Sorarsınız.**.')
   .addField('<a:gold:597165297484693545> `/avatar`', '➠ **Belirttiğiniz Kullanıcıyı Korkutursunuz.**.')
   .addField('<a:gold:597165297484693545> `/emojiyazı`', '➠ **Yazınızı Emoji Yazısına Çevirir.**.')
   .addField('<a:gold:597165297484693545> `/atatürk`', '➠ **Atatürk Resmi Gönderir.**.')
   .addField('<a:gold:597165297484693545> `/google`', '➠ **Google da Söylediğiniz Yazıyı Aratır.**.')
   .addField('<a:gold:597165297484693545> `/sarıl`', '➠ **Belirttiğiniz Kullanıcıya Sarılırsınız.**.')
   .addField('<a:gold:597165297484693545> `/woodie`', '➠ **Woodie Hakkında Bilgi Verir.**.')
   .addField('<a:gold:597165297484693545> `/slots`', '➠ **Slots Oynarsınız.**.')
   .addField('<a:gold:597165297484693545> `/hesapla`', '➠ **Yazdığınız Soruyu Hesaplar.**.')
   .addField('<a:gold:597165297484693545> `/otorol`', '➠ **Sunucuya Giren Kullanıcılara Otomatik Rol Verir.**.')
   .addField('<a:gold:597165297484693545> `/prefix`', '➠ **Botun Ön Ekini Değiştirir.**.')
   .addField('<a:gold:597165297484693545> `/stres-çarkı`', '➠ **Stres Çarkı Çevirir**.')
   .addField('<a:gold:597165297484693545> `/banned`', '➠ **Admin Vurar Ve Gol Olur Dene Ve Gör.**.')
   .addField('<a:gold:597165297484693545> `/çaya-şeker-at`', '➠ **Çaya Şeker Atarsınız**.')
   .addField('<a:gold:597165297484693545> `/çay-iç`', '➠ **Çaya Şeker Atarsınız**.')
   .addField('<a:gold:597165297484693545> `/herkese-benden-çay`', '➠ **Herkese Çay Verir.')
   .addField('<a:gold:597165297484693545> `/kahkaha`', '➠ **Kahkaha Atarsınız')
   .addField('<a:gold:597165297484693545> `/koş`', '➠ **Koşarsınız')
   .addField('<a:gold:597165297484693545> `/starwars`', '➠ **StarWars Gösterir')
   .addField('<a:gold:597165297484693545> `/tokat`', '➠ **Birisine Tokat Atar')
   .addField('<a:gold:597165297484693545> `/ateşet`', '➠ **Kelirttiğiniz Kullanıcıya Ateş Edersiniz')
   .addField('<a:gold:597165297484693545> `/çekiç`', '➠ **İstediğiniz Kişiye Çekiç Atarsınız')
   .addField('<a:gold:597165297484693545> `/bingo`', '➠ **Bingo Oynar**.')
   .addField('<a:gold:597165297484693545> `/bombala`', '➠ **Bomba Atar*.')

   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "eğlence",
  description: "Gerekli komutları gösterir.",
  usage: "eğlence"
};