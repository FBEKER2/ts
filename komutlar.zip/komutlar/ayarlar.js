const Discord = require('discord.js');
const db = require('quick.db');

exports.run = async (client, message, args, member) => {

  let kufurengel = await db.fetch(`kufur_${message.guild.id}`)
  let kufurYazisi;
  if (kufurengel == null) kufurYazisi = 'Küfür filtresi açık değil, ayarlamak için `küfür-engel aç`'
  if (kufurengel == 'acik') kufurYazisi = 'Küfür filtresi açık.'
  if (kufurengel == 'kapali') kufurYazisi = 'Küfür filtresi açık değil, ayarlamak için `küfür-engel aç`'
  
const ayarlar = new Discord.RichEmbed()
.setTitle('Ayarlar:')
.addField('Küfür engelleme', 'kufurYazi')
.setColor('RANDOM')
message.channel.send(ayarlar)
}

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ['ayars', 'ayar-etme-beni'],
  permLevel: 0,
};

exports.help = {
  name: 'ayarlar',
  description: 'Sunucunun ayarlarını gösterir.',
  usage: 'ayarlar'
};