const Discord = require('discord.js');
const client = new Discord.Client();
const ayarlar = require('../ayarlar.json');
const db = require('quick.db')
const randomizeCase = word => word.split('').map(c => Math.random() > 0.5 ? c.toUpperCase() : c.toLowerCase()).join('');

  exports.run = async(bot, message, args) => {
  const i = await db.fetch(`gold_${message.member.id}`)
    if (i == 'ver') {

var prefix = ayarlar.prefix;




const mapping = {
    ' ': '   ',
    '0': ':zero:',
    '1': ':one:',
    '2': ':two:',
    '3': ':three:',
    '4': ':four:',
    '5': ':five:',
    '6': ':six:',
    '7': ':seven:',
    '8': ':eight:',
    '9': ':nine:',
    '!': ':grey_exclamation:',
    '?': ':grey_question:',
    '#': ':hash:',
    '*': ':asterisk:'
};

'abcdefghijklmnopqrstuvwxyz'.split('').forEach(c => {
    mapping[c] = mapping[c.toUpperCase()] = ` :regional_indicator_${c}:`;
});

exports.run = (bot, msg, args) => {
    if (args.length < 1) {
        throw '**Bir mesaj belirt**';
    }

    msg.channel.send(
        args.join(' ')
            .split('')
            .map(c => mapping[c] || c)
            .join('')
    );
  
};
                                                     } else if (!i || i == 'al') {
     message.channel.send('**<:red:555393855856443423> Bu Komutu Sadece Gold Üyeler Kullanabilir\nGold Üyelik İçin <@582579509266743296> İle İletişime Geçiniz**')
    }
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
  kategori: "gold"
};

exports.help = {
  name: 'emojiyazı',
  description: 'Mesajınızı Emojiye Çevirir.',
  usage: 'emojiyazı <mesaj>'
};