const Discord = require('discord.js')
const db = require('quick.db')

exports.run = (client, message, args) => {
if(message.author.id !== '582579509266743296') return message.channel.send('**Bu Komutu Sadece Yapımcım Kullanabilir <:16:598957004391841856>**')
  var gold = args[0]
var id = message.author.id(args[1])
if (!gold) return message.reply("**Lütfen \`ver\` Yada \`al\` Yazın <:warning1:598956539658633236>**")
if (!id) return message.reply("**Üye ID'sini Yazmalısın <:warning1:598956539658633236>**")
  
  if (gold === 'ver') {
 db.set(`gold_${id.id}`, "ver")
  message.channel.send('**Başarılı ' + id.id + " ID'ine Sahip Üye Artık Gold <:onay:598956119393698007>**")
  };

  if (gold === 'al') {
    db.delete(`gold_${id.id}`)
  message.channel.send('**Başarılı ' + id.id + " ID'ine Sahip Üye Artık Gold Değil <:red:598956256748634117>**")
  };
  
};
exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ['gold',],
    permLevel: 0,
};

exports.help = {
    name: 'gold',
    description: 'Premium verir veya alır.',
    usage: 'gold [ver/al] [sunucu ID]'
};