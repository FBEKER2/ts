const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {

   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:597496371179683874> `/canlıdestek`', '➠ **Botun Yapımcılarından Destek Alırsınız.**.')
   .addField('<a:gold:597496371179683874> `/davet`', '➠ **Botu Davet Eder.**.')
   .addField('<a:gold:597496371179683874> `/durdur`', '➠ **Şarkıyı Durdurur..**.')
   .addField('<a:gold:597496371179683874> `/yetkilerim`', '➠ **Yetkilerinizi Gösterir.**.')
   .addField('<a:gold:597496371179683874> `/roller`', '➠ **Sunucuda Bulunan Rolleri Gösterir.**.')
   .addField('<a:gold:597496371179683874> `/tavsiye`', '➠ **Bot İçin Tavisye Verir.**.')
   .addField('<a:gold:597496371179683874> `/fortnite`', '➠ **Fortnite Oyuncu İstatistik Gösterme.**.')
   .addField('<a:gold:597496371179683874> `/kullanıcıbilgim`', '➠ **Bilgilerinizi Gösterir.**.')
   .addField('<a:gold:597496371179683874> `/emojiler`', '➠ **Sunucu da Olan Emojileri Gösterir.**.')
   .addField('<a:gold:597496371179683874> `/sunucubigi`', '➠ **Sunucu Bilgilerini Gösterir.**.')
   .addField('<a:gold:597496371179683874> `/bilgi`', '➠ **Botun Bilgilerini Gösterir**.')
   .addField('<a:gold:597496371179683874> `/sunucular`', '➠ **Botun Bulundugu Sunucuları Gösterir**.')
   .addField('<a:gold:597496371179683874> `/havadurumu`', '➠ **Havadurumunu Gösterir**.')
   .addField('<a:gold:597496371179683874> `/şanslısayım`', '➠ **Şanslı Sayınızı Gösterir**.')
   .addField('<a:gold:597496371179683874> `/kurucu`', '➠ **Sunucunun Kurucusunu Gösterir**.')
   .addField('<a:gold:597496371179683874> `/üyedurum`', '➠ **Üye Durumlarını Ve Sunucudaki Üye Sayısını Gösterir**.')
   .addField('<a:gold:597496371179683874> `/roblox`', '➠ **Roblox Hesabınızdaki Tüm Bilgileri Sorgulayıp Size Gösterir**.')
   .addField('<a:gold:597496371179683874> `/songörülme`', '➠ **İstediğiniz Kişinin Son Görülmesini Gösterir**.')
   .addField('<a:gold:597496371179683874> `/trigger`', '➠ **Avatarınıza Triggered Efekti Verir**.')
   .addField('<a:gold:597496371179683874> `/uptime`', '➠ **Botun Açık Kalma Süresini Gösterir**.')
   .addField('<a:gold:597496371179683874> `/pokemon`', '➠ **Belirtilen Pokemon Hakkında Bilgi Verir**.')
   .addField('<a:gold:597496371179683874> `/çeviri`', '➠ **Belirtilen Belirtilen Dilleri Çevirir /çeviri en tr Yazmanız Yeterli**.')
   .addField('<a:gold:597496371179683874> `/sunucutanıt`', '➠ **Belirtilen Sunucuyu Tanıtır**.')
   .addField('<a:gold:597496371179683874> `/espri`', '➠ **Espri Yapar**.')
   
   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/api/oauth2/authorize?client_id=589606257581883412&permissions=0&scope=bot) **|** [Destek Sunucusu](https://discord.gg/umasfYQ) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});

 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: "kullanıcı",
  description: "Gerekli komutları gösterir.",
  usage: "kullanıcı"
};