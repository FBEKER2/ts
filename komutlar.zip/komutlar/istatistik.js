const Discord = require('discord.js');
const moment = require('moment');
const { version } = require("discord.js");
const os = require('os');
let cpuStat = require("cpu-stat");
const { stripIndents } = require('common-tags');
require('moment-duration-format');

var ayarlar = require('../ayarlar.json');

exports.run = (bot, message, args) => {
    let cpuLol;
    cpuStat.usagePercent(function(err, percent, seconds) {
        if (err) {
            return console.log(err);
        }
        const duration = moment.duration(bot.uptime).format(" D [gün], H [saat], m [dakika], s [saniye]");
        const embedStats = new Discord.RichEmbed()
            .setAuthor(bot.user.username + " | İstatistikler", bot.user.avatarURL)
            .setColor('RANDOM')
            .addField("<:memory:597499263731367966> Bellek Kullanımı", `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} / ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB`)
            .addField("<:blobCoolBoy:597499569361649711> Çalışma Süresi ", `${duration}`)
            .addField("<:yukleniyor:597499581193781267> Bot İstatistikleri", stripIndents`
             » Kullanıcı:  ${bot.users.size.toLocaleString()}
             » Sunucu: ${bot.guilds.size.toLocaleString()}
             » Kanal: ${bot.channels.size.toLocaleString()}
             » Müzik Çalınan Sunucu Sayısı: ${bot.voiceConnections.size ? bot.voiceConnections.size : '0'}
             » Ping: ${Math.round(bot.ping)}ms.
            `)

            .addField("<a:yukleniyor:653204706050572298> Versiyonlar", stripIndents`
            » Discord.js: v${version}
            » Node.js: ${process.version}
            `)
            .addField("<:Staff:597500238160330785> CPU", `\`\`\`md\n${os.cpus().map(i => `${i.model}`)[0]}\`\`\``)
            .addField("<:Staff:597500379940257795> CPU Kullanımı", `\`${percent.toFixed(2)}%\``)
            .addField("<:Staff:597500562082365465> Bit", `\`${os.arch()}\``, true)
            .addField("<:Staff:597500836696031233> İşletim Sistemi", `\`\`${os.platform()}\`\``)
        message.channel.send(embedStats)
    });
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['i'],
    permLevel: `Yetki gerekmiyor. (${0})`
  };

  exports.help = {
    name: 'botayrıntı',
    category: "bot",
    description: 'Botun istatistiklerini gösterir.',
    usage: '.botayrıntı'
  };