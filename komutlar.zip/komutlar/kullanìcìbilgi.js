const moment = require("moment")
const Discord = require("discord.js");
const dateFormat = require('dateformat');

exports.run = (client, message) => {
  
  const online = message.client.emojis.get("597795536719970325");
  const rahatsizetmeyin = message.client.emojis.get("597795536732684289");
  const bosta = message.client.emojis.get("597795843239837716");
  const görünmez = message.client.emojis.get("597795843067871263");
  const kalem = message.client.emojis.get("597796338406653982");
  const kullan = message.client.emojis.get("597796386343223298");
  const botmu = message.client.emojis.get("597796354315649055");
var user;
    let member = message.mentions.users.first();
        let author = message.author; 
        if(member) {
             user = member;
        } else {
             user = author;
        }
    member = message.guild.member(user);
    let roles = member.roles.array().slice(1).sort((a, b) => a.comparePositionTo(b)).reverse().map(role => role.name);
       if (roles.length < 1) roles = ['Bu Kullanıcının Rolü Yok!'];
    const millisCreated = new Date().getTime() - user.createdAt.getTime();
    const daysCreated = moment.duration(millisCreated).format("Y [yıl], D [gün], H [saat], m [dakika], s [saniye]")
    const millisJoined = new Date().getTime() - member.joinedAt.getTime();
    const userJoined = moment.duration(millisJoined).format("Y [yıl], D [gün], H [saat], m [dakika], s [saniye]")
    if(user.presence.status === "dnd"){
      var durum = `${rahatsizetmeyin}` + " Rahatsız Etmeyin"
    }
    else if(user.presence.status === "online"){
      var durum = `${online}` + " Çevrimiçi"
    }
    else if(user.presence.status === "idle"){
      var durum = `${bosta}` + " Boşta"
    }
      else {
      var durum = `${görünmez}` + " Boşta"
    }
      const embed = new Discord.RichEmbed()
      .setColor('RANDOM')
      .setAuthor(user.tag, user.avatarURL || user.defaultAvatarURL)
      .setThumbnail(user.avatarURL || user.defaultAvatarURL)
      .setTitle(`${kullan} Kullanıcı;`)
      .addField("<:gold:597820366202601474> Şu anda oynadığı oyun", user.presence.game ? user.presence.game.name : 'Oynadığı bir oyun yok', true) 
      .addField('Durum:', `${durum}`)
      .addField('<:gold:597820614572507142> Katılım tarihi (Sunucu)', `${userJoined}`, true)
      .addField('<:gold:597820614316916786> Katılım Tarihi (Discord)', `${daysCreated}`, true)
      .addField('<:gold:597499581193781267> Kimlik:', user.id, true)
      .addField(`${botmu} Botmu:`, user.bot ? '\n Evet' : 'Hayır', true)
      .addField('<:gold:597821548996329492> Rolleri:', message.guild.member(user).roles.map(m => m.name).join(' | '), true)
      .addField(`${kalem} Son gönderdiği mesaj:`, user.lastMessage || 'Yok', true)
      .addField('<:gold:597821560161697795> Hesap Oluşturma tarihi:', user.createdAt.toLocaleDateString(), true)
      .setFooter('TRUX Bot Kullanıcı Bilgi Menüsü.', client.user.avatarURL)
      .setTimestamp()
      message.channel.send(embed);
    
    }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['profilim', 'profil', 'kullanıcıbilgi'],
  permLevel: 0
};

exports.help = {
  name: 'kullanıcıbilgim',
  description: 'Profilinizi Gösterir.',
  usage: 'kullanıcıbilgim'
};