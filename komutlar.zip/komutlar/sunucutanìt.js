const Discord = require('discord.js');
exports.run = async (client, message, args) => {
  var channel = client.channels.find('id', '650416011685658625')
    const asdf = await client.channels.get(message.channel.id).createInvite()
  message.delete();
  const embed = new Discord.RichEmbed()
  .setTitle("TRUX Bot | Sunucu Tanıtma Hizmeti")
  .setDescription('Sunucu [Burada](https://discord.gg/N35MCQ4) Tanıtıldı! \n\n Sunucunu Tanıtabilmek İçin Beni [Sunucuna Ekle](https://discordapp.com/oauth2/authorize?client_id=580476521760817162&scope=bot&permissions=8)')
  message.channel.send(embed)
      const invite = new Discord.RichEmbed()
  .setAuthor("TRUX Bot | Sunucu Tanıtma Hizmeti")
  .addField('**<a:gif:597496371179683874> Tanıtan Kullanıcı: **', message.author.username + '#' + message.author.discriminator)
  .addField('**<a:gif:597496371179683874> Sunucu Adı: **', message.guild.name)
  .setThumbnail(message.guild.iconURL)
  .setColor('RANDOM')
  .setDescription(asdf.url)
  channel.send(invite)
};
  
  exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'sunucutanıt',
  description: 'sunucutanıt',
  usage: 'sunucutanıt'
};